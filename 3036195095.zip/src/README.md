# HKU-DASC7606-A2

- Python files has been modified:

  ```
  modeling-phi.py
  eval_fewshot_multigpu.py
  eval_fewshot.py
  acc.py
  ```

  